<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>

<title>HNG Internship 4 #stage1</title>
<link rel="stylesheet" type="text/css" href="style.css">   
</head>
<body>
<div class="container" >
    <span class="title">HNG INTERNSHIP 4 #STAGE1 CHALLENGE
                 DESIGNED BY FRANK</span>
    <div class="time"> 
  <?php
  date_default_timezone_set("Africa/Lagos");
echo "The time is " . date("h:i:a");
  ?>
    </div>
  </div>
</body>
</html>
